Roll No: 213051001
Name: Sagar Poudel
cseLdap: sagarpoudelcse




References:
BootStrap: https://getbootstrap.com/docs/4.3/getting-started/introduction/
Template: https://themewagon.com/themes/free-html5-personal-portfolio-website-template/
NavBar: https://getbootstrap.com/docs/4.0/components/navbar/
        https://themewagon.com/themes/ronin-free-bootstrap-4-html5-personal-portfolio-website-template/
        https://www.w3schools.com/howto/tryit.asp?filename=tryhow_css_fixed_menu
        https://www.w3schools.com/howto/tryit.asp?filename=tryhow_css_smooth_scroll

Social Media Button:
https://www.w3schools.com/howto/howto_css_social_media_buttons.asp

Video:
https://www.w3schools.com/html/html5_video.asp
        
Checkbox:
https://getbootstrap.com/docs/4.5/components/forms/
https://www.w3schools.com/bootstrap/bootstrap_forms_sizing.asp
https://codepen.io/aepicos/pen/bqGqwr
https://stackoverflow.com/questions/4488714/change-label-text-using-javascript
https://stackoverflow.com/questions/12915222/bootstrap-modal-close-modal-when-call-to-action-button-is-clicked
https://www.w3schools.com/howto/howto_js_toggle_hide_show.asp

https://stackoverflow.com/questions/39627549/how-to-center-modal-to-the-center-of-screen/39636961#:~:text=Centering%20the%20modal%20is%20fairly,the%20width%20for%20the%20modal.


Images:
https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.istockphoto.com%2Fphotos%2Fschool-books&psig=AOvVaw1wPJtOp6CNB9uW9uUEPp8T&ust=1628165606596000&source=images&cd=vfe&ved=0CAsQjRxqFwoTCPis79arl_ICFQAAAAAdAAAAABAD
https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.sim-swim.com%2Fen%2Fwhat-is-sim-swim%2F&psig=AOvVaw0kPtuPSkHyALXGnD11ryU-&ust=1628326484713000&source=images&cd=vfe&ved=0CAsQjRxqFwoTCNCX946DnPICFQAAAAAdAAAAABAN
https://www.google.com/url?sa=i&url=https%3A%2F%2Fin.investing.com%2Fanalysis%2Fspecial-report-where-is-the-indian-stock-market-headed-200437066&psig=AOvVaw3kfF2H9cnWeOQGZ-GGuCZq&ust=1628326584110000&source=images&cd=vfe&ved=0CAsQjRxqFwoTCPjHtrSDnPICFQAAAAAdAAAAABAJ
https://www.google.com/url?sa=i&url=https%3A%2F%2Ftheconversation.com%2Fwant-to-become-a-better-person-travelling-more-might-be-the-answer-115009&psig=AOvVaw2X9bfpzYe1xHs6u01NHW8Q&ust=1628326671673000&source=images&cd=vfe&ved=0CAsQjRxqFwoTCKCK7dqDnPICFQAAAAAdAAAAABAD
https://www.google.com/url?sa=i&url=https%3A%2F%2Fblog.bestbuy.ca%2Fhome-furniture-kitchen%2Fkitchen-dining-home-furniture-kitchen%2Fhow-anyone-can-benefit-from-cooking-at-home&psig=AOvVaw3rMo3lV5bjOihBd9ryQHu4&ust=1628326713444000&source=images&cd=vfe&ved=0CAsQjRxqFwoTCOiL6vSDnPICFQAAAAAdAAAAABAJ
https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.tripadvisor.com%2FTourism-g293889-Nepal-Vacations.html&psig=AOvVaw1DDKUzDnK_q0EFPU21yAES&ust=1628405227698000&source=images&cd=vfe&ved=0CAsQjRxqFwoTCIClmbSonvICFQAAAAAdAAAAABAJ
https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.tripadvisor.com%2FTourism-g293891-Pokhara_Gandaki_Zone_Western_Region-Vacations.html&psig=AOvVaw2UfvfqaCCZy3gGn4azXFI-&ust=1628414271867000&source=images&cd=vfe&ved=0CAsQjRxqFwoTCODlvIvKnvICFQAAAAAdAAAAABAD

video:
Used the free versions online video edition platform ClipChamp.
https://app.clipchamp.com/

JS:
https://websitesetup.org/javascript-cheat-sheet/